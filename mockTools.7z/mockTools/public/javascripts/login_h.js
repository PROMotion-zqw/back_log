$(function () {
    document.onreadystatechange = function() {
        $(".test_modal").show();
    }
    let loginBtn = $("#loginBtn"),
        loginForm = $("form"),
        authImgHtml = $(".auth");
    authImg()
    loginBtn.click(function () {
        let loginTable = loginForm.serializeArray(),
            emObj = {};
        loginTable.filter((em, ei) => {
            emObj[em.name] = em.value
        })

        console.log('use', emObj);
        let msg = isEmpty(emObj)
        if (msg) {
            alert(msg)
            return
        }
        // if (!user.val() && !pwd.val()) {
        //     alert('用户和密码不能为空')
        //     return
        // }
        // let bod = {
        //     name: user.val(),
        //     pass: pwd.val()
        // };
        $.ajax({
            type: 'POST',
            url: "/login",
            dataType: 'json',
            headers: {
                "Content-Type": 'application/json',
            },
            data: JSON.stringify(emObj),
            success: function (res) {
                console.log('success-log', res);
                if (res.ok) {
                    location.href = location.origin + "?i=" + Math.random();
                }
            },
            error: function (err) {
                authImg()
                alert(`${err.responseJSON.msg}`)
            }

        })
    })

    document.onkeydown = function (e) {
        if (e.keyCode === 13) {
            loginBtn.click()
        }
    }

    function authImg(str) {
        $.ajax({
            url: '/auths',
            type: "get",
            async: false,
            contentType: "text/plain; charset=utf-8",
            success: function (res) {
                authImgHtml.html(res.img);
                $(".loginload").hide();
            },
            error: function (err) {
                console.log('err', err);
            }
        })
    }
})