$(function () {
    document.onreadystatechange = function() {
        $(".index_modal").show();
        $(".loginload").hide();
    }
})