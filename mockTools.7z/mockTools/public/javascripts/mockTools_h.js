$(function () {
    document.onreadystatechange = function () {
        $(".user_modal").show();
        $(".loginload").hide();
    }
})