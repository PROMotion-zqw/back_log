$(function () {
    document.onreadystatechange = function () {
        $(".user_modal").show();
        $(".loginload").hide();
    }
    let fors = $(".adduser"),
        tem1 = $(".user_list"),
        modals = $(".bd-example-modal-lg"),
        fbox = $("form:eq(1)");
    loadingUserList()
    function loadingUserList() {
        let data = null,
            str = "";
        $.ajax({
            type: "get",
            url: "/userList/getUser",
            dataType: "json",
            // async: false,
            success: (res) => {
                data = res.data
                // let hm = ejs.render(tem1, { data: res.data })
                res.data.filter((v, i) => {
                    str += `
                    <tr>
                    <th scope="row">${i + 1}</th>
                    <td>${v.name}</td>
                    <td>${v.phone}</td>
                    <td>${v.email}</td>
                    <td>
                    <button type="button" class="btn btn-danger btn-sm delUser">删除</button>
                    <button type="button" class="btn btn-secondary btn-sm editUser">修改</button>
                    </td>
                </tr>`
                })
                tem1.html(str)
                $(".delUser").each((di, de) => {
                    de.onclick = null;
                })
                $(".delUser").each((di, de) => {
                    de.delitem = data[di];
                    de.onclick = delUser
                })
            },
            error: (err) => {
                console.log('err-data', err);
                data = []
            }
        })
    }
    // 删除用户
    function delUser(e) {
        $.ajax({
            type: "delete",
            url: "/userList/delUser?name=" + this.delitem.name,
            success: function (res) {
                loadingUserList()
            },
            error: function (err) {
                loadingUserList()
            }
        })
    }
    // 创建用户
    window.createUser = function () {
        let userList = fbox.serializeArray();
        let bod = {};
        bod.createTime = new Date().getTime();
        userList.filter((v, i) => {
            bod[v.name] = v.value
        })
        // return
        let str = isEmpty(bod, { roles: "请选择" })
        if (str) {
            alert(str)
            str = null;
            return
        }
        $.ajax({
            type: 'post',
            url: "/userList/create",
            // dataType: 'json',
            // headers: {
            //     "Content-Type": 'application/json',
            // },
            data: bod,
            success: function (res) {
                // window.location.reload()
                modals.modal('hide');
                reset("form:eq(1)")
                loadingUserList()
            },
            error: function (err) {
                console.log('createUser', err);

                loadingUserList()
                // alert(`${err.responseJSON.msg}`)
            }

        })
    }
    function isEmpty(opt, ObjKeys) {
        let _opt = JSON.parse(JSON.stringify(opt)),
            msg = null;
        switch (Types(_opt)) {
            case "Object":
                for (var ks in _opt) {
                    if (ObjKeys) {
                        if (ks in ObjKeys && ObjKeys[ks] === _opt[ks]) {
                            _opt[ks] = "";
                        }
                    }
                    if (!_opt[ks]) {
                        !msg ? msg = `${ks} 不能为空` : null;
                    }
                }
                if (msg) {
                    return msg
                }
                break;
            case "Array":
                break;
        }
    }
    function Types(ob) {
        return Object.prototype.toString.call(ob).split(" ")[1].split("]")[0]
    }
    function reset(str) {
        $(":input", str).not(':button, :submit, :reset, :hidden')
            .val('')
            .removeAttr('checked')
            .removeAttr('selected');
    }
})