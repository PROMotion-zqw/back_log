function isEmpty(opt, ObjKeys) {
    let _opt = JSON.parse(JSON.stringify(opt)),
        msg = null;
    switch (Types(_opt)) {
        case "Object":
            for (var ks in _opt) {
                if (ObjKeys) {
                    if (ks in ObjKeys && ObjKeys[ks] === _opt[ks]) {
                        _opt[ks] = "";
                    }
                }
                if (!_opt[ks]) {
                    !msg ? msg = `${ks} 不能为空` : null;
                }
            }
            if (msg) {
                return msg
            }
            break;
    }
}
function Types(ob) {
    return Object.prototype.toString.call(ob).split(" ")[1].split("]")[0]
}